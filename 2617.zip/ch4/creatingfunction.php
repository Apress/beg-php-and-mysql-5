<?php

function generate_footer() {
    echo "<p>Copyright &copy; 2005 2006 W. Jason Gilmore</p>";
}

    generate_footer();
?>