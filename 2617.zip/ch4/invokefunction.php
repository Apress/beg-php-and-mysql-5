<?php
    $value = pow(5,3); // returns 125
    echo $value;
?>