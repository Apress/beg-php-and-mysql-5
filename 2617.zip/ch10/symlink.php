<?php
     $link = symlink("/www/htdocs/stats/2003", "/www/htdocs/stats/03");
?>