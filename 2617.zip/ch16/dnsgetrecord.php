<?php
   $result = dns_get_record("example.com");
   print_r($result);
?>