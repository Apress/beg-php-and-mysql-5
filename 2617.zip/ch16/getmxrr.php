<?php
   getmxrr("wjgilmore.com",$mxhosts);
   print_r($mxhosts);
?>