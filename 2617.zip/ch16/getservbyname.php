<?php
   echo "HTTP's default port number is: ".getservbyname("http", "tcp"); 
?>