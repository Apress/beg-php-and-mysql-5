<%
     print "This is another PHP example.";
%>