<html>
   <head>
      <title><?php echo "Welcome to my site!";?></title>
   </head>
   <body>
      <?php
         $date = "May 18, 2006";
      ?>
      <h3>Today's date is <?=$date;?></h3>
   </body>
</html>