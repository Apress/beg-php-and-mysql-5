<?php
   $count = 1;
   while ($count < 5) {
      echo "$count squared = ".pow($count,2). "<br />";
       $count++;
   }
?>