<?php

$cost = sprintf("$%01.2f", 43.2); // $cost = $43.20

echo $cost;

?>