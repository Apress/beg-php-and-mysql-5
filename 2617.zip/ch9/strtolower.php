<?php
   $url = "http://WWW.EXAMPLE.COM/";
   echo strtolower($url);
?>