<?php
   echo str_pad("Salad", 10)." is good.";
?>