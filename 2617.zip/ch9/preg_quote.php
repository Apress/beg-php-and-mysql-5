<?php
   $text = "Tickets for the bout are going for $500.";
   echo preg_quote($text);
?>