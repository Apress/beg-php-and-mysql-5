<?php
   $msg = "i annoy people by capitalizing e-mail text.";
   echo strtoupper($msg);
?>