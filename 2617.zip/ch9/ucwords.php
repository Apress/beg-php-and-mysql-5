<?php
   $title = "O'Malley wins the heavyweight championship!";
   echo ucwords($title);
?>