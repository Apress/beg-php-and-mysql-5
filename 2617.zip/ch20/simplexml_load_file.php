<?php
   $xml = simplexml_load_file("books.xml");
   var_dump($xml);
?>