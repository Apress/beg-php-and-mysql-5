
<html>
   <head>
      <title>{$title}</title>
   </head>
   <body bgcolor="#ffffff" text="#000000" link="#0000ff" 
         vlink="#800080" alink="#ff0000">
   <p>
   Hi, {$name}. Welcome to the wonderful world of Smarty.
   </p>
   </body>
</html>