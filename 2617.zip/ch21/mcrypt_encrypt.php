<?php
   $ivs = mcrypt_get_iv_size(MCRYPT_DES, MCRYPT_MODE_CBC);
   $iv = mcrypt_create_iv($ivs, MCRYPT_RAND);
   $key = "F925T";
   $message = "This is the message I want to encrypt.";
   $enc = mcrypt_encrypt(MCRYPT_DES, $key, $message, MCRYPT_MODE_CBC, $iv);
   echo bin2hex($enc);
?>