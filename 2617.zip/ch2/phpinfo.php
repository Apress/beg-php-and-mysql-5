<?php
     phpinfo();
?>