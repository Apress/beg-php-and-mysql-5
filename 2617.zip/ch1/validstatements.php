<?php
   $number = "5";               # $number is a string
   $sum = 15 + $number;   # Add an integer and string to produce integer
   $sum = "twenty";            # Overwrite $sum with a string.
?>