<?php
   $dn = "OU=People,OU=staff,DC=ad,DC=example,DC=com";
   $dnComponents = ldap_explode_dn($dn, 0);
   foreach($dnComponents as $component)
       echo $component."<br />";
?>