<?php

$date = new Date();
$date->setDMY(4,7,1776);
echo $date->getWeekOfYear();

?>