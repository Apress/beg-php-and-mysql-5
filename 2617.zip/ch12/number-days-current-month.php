<?php

printf("There are %d days in %s.", date("t"), date("F"));

?>