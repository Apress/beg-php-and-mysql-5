<?php

$date = new Date();
$date->setDMY(30,4,2006);
echo $date->getWeekday();

?>