<?php

$grades = array(42,57,98,100,100,43,78,12);
sort($grades);
print_r($grades);

?>