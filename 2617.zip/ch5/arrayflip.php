<?php

$state = array("Delaware","Pennsylvania","New Jersey");
$state = array_flip($state);
print_r($state);

?>