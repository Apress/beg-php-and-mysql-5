<?php

$states = array("Delaware","Pennsylvania","New Jersey");
print_r(array_reverse($states));

?>